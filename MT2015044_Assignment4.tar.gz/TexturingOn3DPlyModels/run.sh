make
#./test.out plyfiles/beethoven.ply plyfiles/beethoven.ply textures/checker.bmp textures/brickwall.bmp
#./test.out plyfiles/beethoven.ply plyfiles/beethoven.ply NA textures/brickwall.bmp
#./test.out plyfiles/beethoven.ply plyfiles/beethoven.ply textures/checker.bmp textures/checker.bmp textures/checker.bmp
#./test.out plyfiles/beethoven.ply plyfiles/beethoven.ply textures/metal.bmp textures/green.bmp textures/stonewall_.bmp
./test.out plyfiles/sphere.ply plyfiles/cylinder.ply textures/world.bmp textures/world.bmp textures/checker.bmp
#./test.out plyfiles/apple.ply plyfiles/trashcan.ply NA NA textures/wood.bmp
